/*1) Write a program that demonstrates widening conversion from int to double and prints the result.*/
public class Windning {
    public static void main(String[] args) {
        int intValue = 100; // Integer value
        double doubleValue = intValue; // Widening conversion from int to double
        System.out.println("Integer value: " + intValue);
        System.out.println("Double value: " + doubleValue);
    }
}