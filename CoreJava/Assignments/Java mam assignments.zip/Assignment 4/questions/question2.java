//2) Create a program that demonstrates narrowing conversion from double to int and prints the result.

public class quetion2 {
    public static void main(String[] args) {
        // Declare a double variable
        double doubleValue = 123.45;
       // Perform narrowing conversion from double to int
        int intValue = (int) doubleValue;
       // Print the original double value and the converted int value
        System.out.println("Original double value: " + doubleValue);
        System.out.println("Converted int value: " + intValue);
    }
}