package in.cdac.Assignment4.Question3;

public class BMITracker {
	private float weight;
	private float height;
	private float bmMI;
	
	
	public BMITracker(float weight, float height) {
		super();
		this.weight = weight;
		this.height = height;
		calculateBMI();
	}


	public float getWeight() {
		return weight;
	}


	public void setWeight(float weight) {
		this.weight = weight;
	}


	public float getHeight() {
		return height;
	}


	public void setHeight(float height) {
		this.height = height;
	}

	 private void calculateBMI() {
	        if (height > 0) {
	            this.bmMI = weight / (height * height);
	        }
	    }
	
	public float classifyBMI () {
		
		
		System.out.println(" BMI is :"+ this.bmMI);
		
		if (bmMI < 18.5)
		{
			System.out.println("under weight" );
			
		}
		else if(18.5 <= bmMI && bmMI < 24.9)
		{
			System.out.println("Normal weight" );
		}
		else if(25 <= bmMI && bmMI < 29.9)
		{
			System.out.println("Over weight" );
		}
		else if(30 <= bmMI)
		{
			System.out.println(" Obese" );
		}
		else
		{	System.out.println(" Enter correct weight and height" );
		
		}
		return bmMI;
			
	}


	
	@Override
    public String toString() {
        return String.format("BMI: %.2f\n%s", bmMI, classifyBMI());

}

}
