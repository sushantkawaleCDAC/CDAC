package in.cdac.Assignment4.Question3;

import java.util.Scanner;

public class BMITrackerUtil {
	 private Scanner sc = new Scanner(System.in);

	    public BMITracker acceptRecord() {
	        System.out.print("Enter weight : ");
	        float weight = sc.nextFloat();
	        System.out.print("Enter height : ");
	        float height = sc.nextFloat();
	        return new BMITracker(weight, height);
	    }

	    public void printRecord(BMITracker tracker) {
	    	System.out.println(tracker);
	    }
	    
	    

	    // Method to display the menu
	    public void menuList() {
	        System.out.println("1. Calculate BMI");
	        System.out.println("2. Display the BMI value and its classification");
	        System.out.println("3. Exit");
	    }
	}