package in.cdac.Assignment4.Question3;

import java.util.Scanner;


public class program {
    public static void main(String[] args) {
		 BMITrackerUtil util = new BMITrackerUtil();
	        Scanner scanner = new Scanner(System.in);
	        
	        int choice;

	        do {
	            util.menuList();
	            System.out.print("Enter your choice: ");
	            choice = scanner.nextInt();

	            BMITracker tracker = null;
				switch (choice) {
	                case 1:
	                	tracker = util.acceptRecord();  // Accept new record
	                    util.printRecord(tracker);     
	                    break;
	                case 2:
	                	util.printRecord(tracker);    
	                    break;
	                case 3:
	                    System.out.println("Exiting...");
	                    break;
	                default:
	                    System.out.println("Invalid choice! Please select a valid option.");
	            }
	        } while (choice != 3);  // Repeat menu until user selects "Exit"
	        
	        scanner.close();
	    }
	}