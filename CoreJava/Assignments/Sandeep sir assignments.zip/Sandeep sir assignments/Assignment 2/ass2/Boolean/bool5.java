public class Qg{
public static void main(String args [])
{
boolean status=false;
int strbool = (status) ? 1 :0;
System.out.println("Boolean to Int: "+strbool);
}
}