public class bool1{
public static void main(String args[]){
	String strStatus =new String("true");
	boolean boolstatus=Boolean.parseBoolean(strStatus);
	System.out.println(" String to boolean  "+boolstatus);
	}
}