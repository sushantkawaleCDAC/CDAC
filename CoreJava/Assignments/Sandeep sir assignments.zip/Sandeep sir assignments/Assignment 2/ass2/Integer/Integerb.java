/* b. Write a program to test how many bytes are used to represent an int value using the BYTES field. (Hint: Use Integer.BYTES).*/
public class Integerb {
    public static void main(String[] args) {
        System.out.println("Bytes used to represent an int value: " + Integer.BYTES);
    }
}
