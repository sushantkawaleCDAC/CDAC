//b. Write a program to test how many bytes are used to represent a byte value using the BYTES field. (Hint: Use Byte.BYTES).

class Byteb{
	public static void main(String args[]){
		  int bytesUsed = Byte.BYTES;
		 System.out.println("Bytes used to represent a byte value: " +bytesUsed);
	}
}