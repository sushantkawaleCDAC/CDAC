/*l. Declare two float variables with the same value, 0.0f, and divide them. (Hint: Observe the result and any special floating-point behavior).*/
public class floatL {
    public static void main(String[] args) {
        float a = 0.0f;
        float b = 0.0f;
        float result = a / b; 
        System.out.println("0.0 / 0.0 = " + result);
    }
}
