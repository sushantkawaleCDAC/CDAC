/*k. Declare a float variable with the value -25.0f. Find the square root of this value. (Hint: Use Math.sqrt() method).*/
public class floatK {
    public static void main(String[] args) {
        float number = -25.0f;
        double sqrt = Math.sqrt(number);  
        System.out.println("Square root of -25.0: " + sqrt);
    }
}
