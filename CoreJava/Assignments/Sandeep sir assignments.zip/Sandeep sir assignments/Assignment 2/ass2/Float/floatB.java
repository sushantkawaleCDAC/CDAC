/*b. Write a program to test how many bytes are used to represent a float value using the BYTES field. (Hint: Use Float.BYTES).*/
public class FloatB {
    public static void main(String[] args) {
        System.out.println("Size: " + Float.BYTES);
    }
}
