/*b. Write a program to test how many bytes are used to represent a short value using the BYTES field. (Hint: Use Short.BYTES).*/
public class ShortB {
    public static void main(String[] args) {
        System.out.println("Bytes used to represent a short value: " + Short.BYTES);
    }
}
