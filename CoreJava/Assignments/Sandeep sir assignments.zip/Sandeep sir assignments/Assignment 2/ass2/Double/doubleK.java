/*k. Declare a double variable with the value -25.0. Find the square root of this value. (Hint: Use Math.sqrt() method).*/
public class doubleK {
    public static void main(String[] args) {
        double number = -25.0;
        double sqrt = Math.sqrt(number);
        System.out.println("Square root of " + number + " is: " + sqrt);
    }
}
