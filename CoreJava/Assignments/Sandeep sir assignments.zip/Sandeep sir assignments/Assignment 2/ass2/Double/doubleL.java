/*l. Declare two double variables with the same value, 0.0, and divide them. (Hint: Observe the result and any special floating-point behavior).*/
public class doubleL {
    public static void main(String[] args) {
        double num1 = 0.0;
        double num2 = 0.0;
        double result = num1 / num2;
        System.out.println("Result of dividing 0.0 by 0.0: " + result);
    }
}
