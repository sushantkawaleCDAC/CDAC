/*b. Write a program to test how many bytes are used to represent a double value using the BYTES field. (Hint: Use Double.BYTES).*/
public class DoubleB {
    public static void main(String[] args) {
        System.out.println("Number of bytes used to represent a double: " + Double.BYTES);
    }
}
