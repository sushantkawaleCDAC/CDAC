/*f. Declare a method-local variable strNumber of type String with the value "Ab12Cd3" and attempt to convert it to a long value. (Hint: parseLong method will throw a NumberFormatException).*/
 class InvalidStringToLong {
    public static void main(String[] args) {
        String strNumber = "Ab12Cd3"; // Method-local variable
         System.out.println("NumberFormatException: " + e.getMessage());

    }
}

