/*c. Write a program to find the minimum and maximum values of long using the MIN_VALUE and MAX_VALUE fields. (Hint: Use Long.MIN_VALUE and Long.MAX_VALUE).*/
 class LongMinMax {
    public static void main(String[] args) {
        System.out.println("Min value of long: " + Long.MIN_VALUE);
        System.out.println("Max value of long: " + Long.MAX_VALUE);
    }
}

//package employee;


