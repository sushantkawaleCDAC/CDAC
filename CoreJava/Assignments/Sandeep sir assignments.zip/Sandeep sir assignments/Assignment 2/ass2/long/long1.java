/*Write a program to test how many bytes are used to represent a long value using the BYTES field. (Hint: Use Long.BYTES).*/
public class LongBytes {
    public static void main(String[] args) {
        System.out.println("Bytes used by long: " + Long.BYTES);
    }
}
